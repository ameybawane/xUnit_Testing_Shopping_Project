﻿using AutoFixture;
using Moq;
using Shopping.BLL;
using Shopping.DAL;
using Shopping.Lib;
using ShoppingTestProject.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ShoppingTestProject.Shopping.BLL
{
    public class DiscountCalculatorTests : ApiUnitTestBase<DiscountCalculator>
    {
        private Mock<IFestivalRepository> mockFestivalRepository;
        private Mock<IPromoCodeRepository> mockPromoCodeRepository;
        public override void TestSetup()
        {
            mockFestivalRepository = this.CreateAndInjectMock<IFestivalRepository>();
            mockPromoCodeRepository = this.CreateAndInjectMock<IPromoCodeRepository>();

            Target = new DiscountCalculator(mockFestivalRepository.Object, mockPromoCodeRepository.Object);
        }

        public override void TestTearDown()
        {
            mockFestivalRepository.VerifyAll();
            mockPromoCodeRepository.VerifyAll();
        }

        [Fact]
        public void CalculateFestivalDiscount_Found()
        {
            // Arrange
            var date = Fixture.Create<DateTime>();
            var festivalDiscount = Fixture.Create<Discount>();
            this.mockFestivalRepository.Setup(c => c.GetFestivalDiscountByShoppingDate(date)).Returns(festivalDiscount);
            
            // Act
            var actual = Target.CalculateFestivalDiscount(date);
            
            // Assert
            Assert.NotNull(actual);
            Assert.Equal(festivalDiscount, actual);
            this.mockFestivalRepository.Verify(c => c.GetFestivalDiscountByShoppingDate(date), Times.Once);
        }

        [Fact]
        public void CalculateFestivalDiscount_NotFound()
        {
            // Arrange
            var date = Fixture.Create<DateTime>();
            Discount festivalDiscount = null;
            this.mockFestivalRepository.Setup(c => c.GetFestivalDiscountByShoppingDate(date)).Returns(festivalDiscount);
            
            // Act
            var actual = Target.CalculateFestivalDiscount(date);
            
            // Assert
            Assert.Null(actual);
            Assert.Equal(festivalDiscount, actual);
            this.mockFestivalRepository.Verify(c => c.GetFestivalDiscountByShoppingDate(date), Times.Once);
        }
    }
}
