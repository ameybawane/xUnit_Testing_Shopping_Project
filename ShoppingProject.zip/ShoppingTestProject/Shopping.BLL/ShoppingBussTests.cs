﻿using AutoFixture;
using Moq;
using Shopping.BLL;
using Shopping.DAL;
using Shopping.Lib;
using ShoppingTestProject.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ShoppingTestProject.Shopping.BLL
{
    public class ShoppingBussTests : ApiUnitTestBase<ShoppingBusiness>
    {
        private Mock<IShoppingProductRepository> mockShoppingRepository;
        private Mock<IDiscountCalculator> mockDiscountRepository;
        public override void TestSetup()
        {
            mockShoppingRepository = this.CreateAndInjectMock<IShoppingProductRepository>();
            mockDiscountRepository = this.CreateAndInjectMock<IDiscountCalculator>();
            Target = new ShoppingBusiness(mockShoppingRepository.Object, mockDiscountRepository.Object);
        }

        public override void TestTearDown()
        {
            mockShoppingRepository.VerifyAll();
            mockDiscountRepository.VerifyAll();
        }

        [Fact]
        public void GetProducts_Found()
        {
            // Arrange
            var products = Fixture.CreateMany<ShoppingProduct>();
            this.mockShoppingRepository.Setup(c => c.GetShoppingProducts()).Returns(products);

            // Act
            var actual = Target.GetProducts();

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(products, actual);
            this.mockShoppingRepository.Verify(c => c.GetShoppingProducts(), Times.Once);
        }

        [Fact]
        public void GetProducts_NotFound()
        {
            // Arrange
            IEnumerable<ShoppingProduct> products = null;
            this.mockShoppingRepository.Setup(c => c.GetShoppingProducts()).Returns(products);

            // Act
            var actual = Target.GetProducts();

            // Assert
            Assert.Null(actual);
            Assert.Equal(products, actual);
            this.mockShoppingRepository.Verify(c => c.GetShoppingProducts(), Times.Once);
        }

        [Fact]
        public void GetProductById_Found()
        {
            // Arrange
            int id = Fixture.Create<int>();
            var product = Fixture.Create<ShoppingProduct>();
            product.Id = id;
            product.IsMerchantDiscountAllowed = false;
            this.mockShoppingRepository.Setup(c => c.GetShoppingProductById(id)).Returns(product);

            // Act
            var actual = Target.GetProductById(id);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(product, actual);
            this.mockShoppingRepository.Verify(c => c.GetShoppingProductById(id), Times.Once);
        }

        [Fact]
        public void GetProductById_NotFound()
        {
            // Arrange
            int id = 9;
            ShoppingProduct product = null;
            this.mockShoppingRepository.Setup(c => c.GetShoppingProductById(id)).Returns(product);

            // Act
            var actual = Target.GetProductById(id);

            // Assert
            Assert.Null(actual);
            Assert.Equal(product, actual);
            this.mockShoppingRepository.Verify(c => c.GetShoppingProductById(id), Times.Once);
        }

        [Fact]
        public void GetProductById_ProductNull()
        {
            // Arrange
            int id = 9;
            ShoppingProduct product = null;
            this.mockShoppingRepository.Setup(c => c.GetShoppingProductById(id)).Returns(product);

            // Act
            var actual = Target.GetProductById(id);

            // Assert
            Assert.Null(actual);
            Assert.Equal(product, actual);
            this.mockShoppingRepository.Verify(c => c.GetShoppingProductById(id), Times.Once);
        }

        [Fact]
        public void ApplyFestivalDiscount_WithProduct()
        {
            // Arrange
            var product = Fixture.Create<ShoppingProduct>();

            // Act
            var actual = Target.ApplyFestivalDiscount(product);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(product, actual);
        }

        [Fact]
        public void ApplyFestivalDiscount_WithEmptyProduct()
        {
            // Arrange
            var product = Fixture.Create<ShoppingProduct>();
            product.FestivalDiscount = null;

            // Act
            var actual = Target.ApplyFestivalDiscount(product);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(product, actual);
        }

    }
}
