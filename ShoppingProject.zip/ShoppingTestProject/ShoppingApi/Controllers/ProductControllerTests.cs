﻿using AutoFixture;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Newtonsoft.Json;
using ShoppingApi.Controllers;
using ShoppingApi.Models;
using ShoppingTestProject.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ShoppingTestProject.ShoppingApi.Controllers
{
    public class ProductControllerTests : ApiUnitTestBase<ProductController>
    {
        private Mock<IProductRepository> mockProductRepository;
        public override void TestSetup()
        {
            mockProductRepository = this.CreateAndInjectMock<IProductRepository>();
            Target = new ProductController(mockProductRepository.Object);
        }

        public override void TestTearDown()
        {

            mockProductRepository.VerifyAll();
        }

        [Fact]
        public void GetAll_ValueFound()
        {
            // Arrange
            var products = Fixture.CreateMany<Product>();
            this.mockProductRepository.Setup(c => c.GetAll()).Returns(products);

            // Act
            var actual = Target.GetAll();

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(products, actual);
            this.mockProductRepository.Verify(c => c.GetAll(), Times.Once);
        }

        [Fact]
        public void GetAll_ValueNotFound()
        {
            // Arrange
            IEnumerable<Product> products = null;
            this.mockProductRepository.Setup(c => c.GetAll()).Returns(products);

            // Act
            var actual = Target.GetAll();

            // Assert
            Assert.Null(actual);
            Assert.Equal(products, actual);
            this.mockProductRepository.Verify(c => c.GetAll(), Times.Once);
        }

        [Fact]
        public void GetById_ValueFound()
        {
            // Arrange
            int id = Fixture.Create<int>();
            var product = Fixture.Create<Product>();
            product.Id = id;
            this.mockProductRepository.Setup(c => c.GetById(id)).Returns(product);

            // Act
            var actual = Target.GetById(id) as ObjectResult;

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(product, actual.Value);
            Assert.Equal((int)HttpStatusCode.OK, actual.StatusCode);
            this.mockProductRepository.Verify(c => c.GetById(id), Times.Once);
        }

        [Fact]
        public void GetById_ValueNotFound()
        {
            // Arrange
            int id = Fixture.Create<int>();
            Product product = null;
            this.mockProductRepository.Setup(c => c.GetById(id)).Returns(product);

            // Act
            var actual = Target.GetById(id) as NotFoundResult;

            // Assert
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            this.mockProductRepository.Verify(c => c.GetById(id), Times.Once);
        }

        [Fact]
        public void CreateProduct_ResultOk()
        {
            // Arrange
            var product = Fixture.Create<Product>();
            this.mockProductRepository.Setup(c => c.Add(product));

            // Act
            var actual = Target.Create(product);

            // Assert.
            var actionResult = Assert.IsType<OkResult>(actual);
            Assert.Equal((int)HttpStatusCode.OK, actionResult.StatusCode);
            this.mockProductRepository.Verify(c => c.Add(product), Times.Once);
        }


        [Fact]
        public void CreateProduct_BadRequestResult()
        {
            // Act
            Product product = null;
            var actual = Target.Create(product);

            // Assert
            var actionResult = Assert.IsType<BadRequestResult>(actual);
            Assert.Equal((int)HttpStatusCode.BadRequest, actionResult.StatusCode);
            mockProductRepository.Verify(c => c.Add(null), Times.Never);
        }

        [Fact]
        public void Delete_IdExists()
        {
            // Arrange
            int id = Fixture.Create<int>();
            var product = Fixture.Create<Product>();
            product.Id = id;
            this.mockProductRepository.Setup(c => c.Remove(id)).Returns(product);

            // Act
            var actual = Target.Delete(id);

            // Assert
            Assert.NotNull(actual);
            Assert.Equal(product, actual);
            this.mockProductRepository.Verify(c => c.Remove(id), Times.Once);

        }

        [Fact]
        public void Delete_IdNotExists()
        {
            // Arrange
            int id = Fixture.Create<int>();
            Product product = null;
            this.mockProductRepository.Setup(c => c.Remove(id)).Returns(product);

            // Act
            var actual = Target.Delete(id);

            // Assert
            Assert.Null(actual);
            Assert.Equal(product, actual);
            this.mockProductRepository.Verify(c => c.Remove(id), Times.Once);
        }

        [Fact]
        public void Update_Returnok()
        {
            // Arrange
            var id = Fixture.Create<int>();
            var product = Fixture.Create<Product>();
            product.Id = id;
            mockProductRepository.Setup(c => c.GetById(id)).Returns(product);
            mockProductRepository.Setup(c => c.Update(product));

            // Act
            var actual = Target.Update(id, product) as StatusCodeResult;

            // Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.OK, actual.StatusCode);
            mockProductRepository.Verify(c => c.GetById(id), Times.Once);
            mockProductRepository.Verify(c => c.Update(product), Times.Once);
        }

        [Fact]
        public void Update_ReturnBadRequest()
        {
            // Arrange
            var id = Fixture.Create<int>();
            var product = Fixture.Create<Product>();

            // Act
            var actual = Target.Update(id, product) as StatusCodeResult;

            // Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.BadRequest, actual.StatusCode);
        }

        [Fact]
        public void GetProductsWithPaging_ReturnOK()
        {
            //Arrange
            var products = new List<Product>();
            products.Add(new Product { Id = 1, Name = "ABC", Description = "temp", IsMerchantDiscountAllowed = true, Price = 99, Quantity = 7 });
            products.Add(new Product { Id = 2, Name = "XYZ", Description = "desc", IsMerchantDiscountAllowed = false, Price = 60, Quantity = 17 });
            PagedList<Product> productList = new PagedList<Product>(products, 33, 1, 10);
            var data = new QueryParameters()
            {
                PageNumber = 1,
                PageSize = 10,
            };
            this.mockProductRepository.Setup(c => c.GetPagedProducts(data)).Returns(productList);
            var paginationMetadataSample = new
            {
                totalCount = productList.TotalCount,
                pageSize = productList.PageSize,
                currentPage = productList.CurrentPage,
                totalPages = productList.TotalPages,
                previousPage = productList.HasPrevious,
                nextPage = productList.HasNext
            };
            JsonConvert.SerializeObject(data);

            //Act
            var actual = Target.GetProductsWithPaging(data) as ObjectResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(productList, actual.Value);
            Assert.Equal((int)HttpStatusCode.OK, actual.StatusCode);
            this.mockProductRepository.Verify(c => c.GetPagedProducts(data), Times.Once);
        }
    }
}
