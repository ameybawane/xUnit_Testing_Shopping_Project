﻿using AutoFixture;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Shopping.BLL;
using Shopping.Lib;
using ShoppingTestProject.Utilities;
using ShoppingApplication.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ShoppingTestProject.ShoppingApplication.Controllers
{
    public class ProductControllerTests : ApiUnitTestBase<ProductController>
    {
        private Mock<IShoppingBusiness> mockShoppingBusiness;

        public override void TestSetup()
        {
            mockShoppingBusiness = this.CreateAndInjectMock<IShoppingBusiness>();
            Target = new ProductController(mockShoppingBusiness.Object);
        }

        public override void TestTearDown()
        {
            mockShoppingBusiness.VerifyAll();
        }

        [Fact]
        public void IndexById()
        {
            // Arrange
            var product = Fixture.Create<ShoppingProduct>();
            // ShoppingBusiness product = null;
            var id = Fixture.Create<int>();
            this.mockShoppingBusiness.Setup((c) => c.GetProductById(id)).Returns(product);

            // Act
            ViewResult view = Target.Index(id) as ViewResult;

            // Assert
            Assert.NotNull(view);
            Assert.Equal(product, view.Model);
            mockShoppingBusiness.Verify(m => m.GetProductById(id), Times.Once());
        }

        [Fact]
        public void IndexByIdNotFound()
        {
            // Arrange
            // var product = Fixture.Create<ShoppingProduct>();
            ShoppingProduct product = null;
            var id = Fixture.Create<int>();
            this.mockShoppingBusiness.Setup((c) => c.GetProductById(id)).Returns(product);

            // Act
            ViewResult view = Target.Index(id) as ViewResult;

            // Assert
            Assert.NotNull(view);
            Assert.Equal(product, view.Model);
            mockShoppingBusiness.Verify(m => m.GetProductById(id), Times.Once());
        }

        [Fact]
        public void ThanksRetrunView()
        {
            // Arrange

            // Act
            ViewResult view = Target.Thanks() as ViewResult;

            // Assert           
            RedirectResult redirect = (RedirectResult)view.Model;
        }
    }
}
