﻿using AutoFixture;
using Helper;
using Microsoft.AspNetCore.Mvc;
using Moq;
using ShoppingApplication.Controllers;
using ShoppingApplication.Models;
using ShoppingTestProject.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ShoppingTestProject.ShoppingApplication.Controllers
{
    public class RegisterControllerTests : ApiUnitTestBase<RegisterController>
    {

        private Mock<IValidationHelper> mockValidationHelper;

        public override void TestSetup()
        {
            mockValidationHelper = this.CreateAndInjectMock<IValidationHelper>();
            Target = new RegisterController(mockValidationHelper.Object);
        }

        public override void TestTearDown()
        {
            mockValidationHelper.VerifyAll();
        }

        [Fact]
        public void Index_RetrunView()
        {
            // Arrange

            // Act
            ViewResult view = Target.Index() as ViewResult;

            // Assert           
            RedirectResult redirect = (RedirectResult)view.Model;
        }
    }
}
