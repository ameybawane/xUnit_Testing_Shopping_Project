﻿namespace Shopping.Lib
{
    public enum DiscountOption
    {
        Amount,
        Percentage
    }
}
